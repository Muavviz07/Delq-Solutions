import React from 'react';

export default function ServicesSection() {
  return (
    <section className="bg-white py-16 md:py-28 px-10 sm:px-14 md:px-20"> {/* Further increased horizontal padding */}
      <div className="container mx-auto text-center">
        <p className="text-xs font-semibold tracking-[0.2em] text-black mb-3 sm:mb-4">
          BARRIER BREAKING SERVICES
        </p>
        <h2
          className="text-3xl md:text-5xl font-bold text-[#1c1c1c] leading-snug sm:leading-loose"
          style={{ fontFamily: "'Urbanist', sans-serif" }}
        >
          Elevate Your Business With
          <br />
          <span className="text-[#d90a2c] underline">Next-Gen</span> IT Services
        </h2>
      </div>
    </section>
  );
}
