import React, { useState, useEffect, useRef } from 'react';

// --- Reusable Checkmark Icon ---
const CheckIcon = () => (
    <svg className="w-5 h-5 text-[#d90a2c] mr-3 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
    </svg>
);

// --- Component 3: Culture Accordion Icons ---
const IconNorthEast = () => ( // Open state
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M7 17L17 7M9 7h8v8" />
    </svg>
);
const IconSouthWest = () => ( // Closed state
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M17 7L7 17M15 17H7V9" />
    </svg>
);

// --- Component 3: Culture Accordion Item ---
const CultureItem = ({ value, isActive, onToggle }) => {
    const contentRef = useRef(null);
    const [contentHeight, setContentHeight] = useState('0px');

    useEffect(() => {
        // Set the max-height for smooth transition
        setContentHeight(isActive ? `${contentRef.current.scrollHeight}px` : '0px');
    }, [isActive]);

    return (
        <div 
            className={`rounded-lg transition-colors duration-300 ${isActive ? 'bg-[#d90a2c]' : 'bg-gray-100'}`}
        >
            <button 
                onClick={onToggle}
                className={`w-full flex justify-between items-center p-6 text-left ${isActive ? 'text-white' : 'text-black'}`}
            >
                <div className="flex items-center">
                    {/* 1. Black, bold, larger letter */}
                    <span 
                        className="text-5xl font-bold text-black mr-4"
                        style={{ fontFamily: "'Urbanist', sans-serif" }}
                    >
                        {value.letter}
                    </span>
                    <h3 
                        className="text-2xl font-bold"
                        style={{ fontFamily: "'Urbanist', sans-serif" }}
                    >
                        {value.title}
                    </h3>
                </div>
                {/* 2. Swapping icons based on state */}
                {isActive ? <IconNorthEast /> : <IconSouthWest />}
            </button>
            {/* 3. Smooth animation wrapper */}
            <div
                ref={contentRef}
                style={{ maxHeight: contentHeight }}
                className="overflow-hidden transition-all duration-500 ease-in-out"
            >
                <div className="px-6 pb-6 -mt-2 pl-20">
                    <p className="text-base text-white/90 leading-relaxed">
                        {value.description}
                    </p>
                </div>
            </div>
        </div>
    );
};


// --- Main Page Component ---
export default function MissionVisionPage() {
    const [pageData, setPageData] = useState(null);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState(null);
    // Set 'L' (Learning) to be active by default, matching ref img
    const [activeCultureTab, setActiveCultureTab] = useState(2); 

    useEffect(() => {
        window.scrollTo(0, 0);
        const fetchData = async () => {
          setIsLoading(true);
          setError(null);
          try {
            const response = await fetch('http://localhost:8000/api/mission-vision-data');
            if (!response.ok) throw new Error(`Data fetching failed for Mission/Vision page`);
            const data = await response.json();
            setPageData(data);
          } catch (e) {
            setError(e.message);
            console.error("Failed to fetch page data:", e);
          } finally {
            setIsLoading(false);
          }
        };
        fetchData();
    }, []);

    if (isLoading) {
        return <div className="h-screen w-full flex items-center justify-center text-2xl font-bold">Loading Page...</div>;
    }
    if (error) {
        return <div className="h-screen w-full flex items-center justify-center text-red-500">{error}</div>;
    }
    if (!pageData) return null;

    return (
        <main className="bg-white">
            <div className="container mx-auto max-w-7xl py-20 md:py-28 px-4 sm:px-6 lg:px-8 space-y-24 md:space-y-32">

                {/* --- Component 1: Our Mission (image_aae58f.jpg) --- */}
                <section>
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 md:gap-16 items-center">
                        
                        {/* Left Image Block */}
                        <div className="relative h-[400px] md:h-[550px]">
                            <img 
                                src={pageData.missionImgBg} 
                                alt="Mission background"
                                className="w-full h-full object-cover rounded-3xl shadow-lg"
                            />
                            <img 
                                src={pageData.missionImgOverlap}
                                alt="Our mission"
                                className="absolute w-2/3 h-auto -bottom-12 -right-12 object-cover rounded-2xl shadow-xl border-8 border-white"
                            />
                        </div>

                        {/* Right Content Block */}
                        <div className="lg:pl-8">
                            <h2 
                                className="text-4xl md:text-5xl font-bold text-black"
                                style={{ fontFamily: "'Urbanist', sans-serif" }}
                            >
                                {pageData.missionHeading}
                            </h2>
                            <p className="text-base text-gray-600 leading-relaxed my-6">
                                {pageData.missionDescription}
                            </p>
                            <ul className="space-y-4">
                                {pageData.missionFeatures.map((feature, index) => (
                                    <li key={index} className="flex items-center">
                                        <CheckIcon />
                                        <span className="text-base font-semibold text-gray-700">{feature}</span>
                                    </li>
                                ))}
                            </ul>
                        </div>
                    </div>
                </section>

                {/* --- Component 2: Our Vision (image_aae5ed.jpg) --- */}
                <section>
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 md:gap-16 items-center">
                        
                        {/* Left Content Block */}
                        <div className="lg:pr-8 row-start-2 lg:row-start-1">
                            <h2 
                                className="text-4xl md:text-5xl font-bold text-black"
                                style={{ fontFamily: "'Urbanist', sans-serif" }}
                            >
                                {pageData.visionHeading}
                            </h2>
                            <p className="text-base text-gray-600 leading-relaxed my-6">
                                {pageData.visionDescription}
                            </p>
                            <ul className="space-y-4">
                                {pageData.visionFeatures.map((feature, index) => (
                                    <li key={index} className="flex items-center">
                                        <CheckIcon />
                                        <span className="text-base font-semibold text-gray-700">{feature}</span>
                                    </li>
                                ))}
                            </ul>
                        </div>
                        
                        {/* Right Image Block */}
                        <div className="relative h-[400px] md:h-[550px] row-start-1 lg:row-start-1">
                            <img 
                                src={pageData.visionImgBg}
                                alt="Vision background"
                                className="w-full h-full object-cover rounded-3xl shadow-lg"
                            />
                            <img 
                                src={pageData.visionImgOverlap}
                                alt="Our vision"
                                className="absolute w-2/3 h-auto -bottom-12 -left-12 object-cover rounded-2xl shadow-xl border-8 border-white"
                            />
                        </div>
                    </div>
                </section>

                {/* --- Component 3: Our Culture (image_aae62b.jpg) --- */}
                <section>
                    <div className="mb-12 max-w-3xl">
                        <h2 
                            className="text-4xl md:text-5xl font-bold text-black"
                            style={{ fontFamily: "'Urbanist', sans-serif" }}
                        >
                            {pageData.cultureHeading}
                        </h2>
                        <p className="text-base text-gray-600 leading-relaxed mt-4">
                            {pageData.cultureDescription}
                        </p>
                    </div>

                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 md:gap-16 items-center">
                        {/* 4. Left Image (Static size) */}
                        <div>
                            <img
                                src={pageData.cultureImg}
                                alt="Our culture"
                                // Set a fixed height that works well and is independent
                                className="w-full h-[500px] object-cover rounded-2xl shadow-lg"
                            />
                        </div>

                        {/* 5. Right Accordion (Responsive) */}
                        <div className="space-y-4">
                            {pageData.cultureValues.map((value, index) => (
                                <CultureItem 
                                    key={value.letter}
                                    value={value}
                                    isActive={activeCultureTab === index}
                                    onToggle={() => setActiveCultureTab(activeCultureTab === index ? null : index)}
                                />
                            ))}
                        </div>
                    </div>
                </section>

            </div>
        </main>
    );
}