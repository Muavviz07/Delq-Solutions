import React, { useState, useEffect } from 'react';

// Helper function to render HTML from string
const createMarkup = (htmlString) => {
    return { __html: htmlString };
};

// --- SVG Icons for Component 2 Benefits ---
const IconAutomation = () => (
    <svg className="w-full h-full" viewBox="0 0 80 80" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect width="80" height="80" rx="12" fill="#F4F7FB"/>
        <rect x="16" y="48" width="48" height="16" rx="4" fill="#D90A2C"/>
        <rect x="24" y="24" width="32" height="16" rx="4" fill="#2C3E50"/>
    </svg>
);
const IconProductivity = () => (
    <svg className="w-full h-full" viewBox="0 0 80 80" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect width="80" height="80" rx="12" fill="#F4F7FB"/>
        <rect x="16" y="44" width="48" height="20" rx="4" fill="#2C3E50"/>
        <rect x="16" y="16" width="28" height="20" rx="4" fill="#D90A2C"/>
        <rect x="52" y="16" width="12" height="20" rx="4" fill="#2C3E50"/>
    </svg>
);
const IconExpertise = () => (
    <svg className="w-full h-full" viewBox="0 0 80 80" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect width="80" height="80" rx="12" fill="#F4F7FB"/>
        <rect x="16" y="52" width="48" height="12" rx="4" fill="#D90A2C"/>
        <rect x="16" y="32" width="48" height="12" rx="4" fill="#2C3E50"/>
        <rect x="16" y="12" width="48" height="12" rx="4" fill="#D90A2C"/>
    </svg>
);
const BenefitIcons = [<IconAutomation />, <IconProductivity />, <IconExpertise />];

export default function OurTeamPage() {
    const [pageData, setPageData] = useState(null);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        window.scrollTo(0, 0);
        const fetchData = async () => {
          setIsLoading(true);
          setError(null);
          try {
            const response = await fetch('http://localhost:8000/api/our-team-data');
            if (!response.ok) throw new Error(`Data fetching failed for Our Team page`);
            const data = await response.json();
            setPageData(data);
          } catch (e) {
            setError(e.message);
            console.error("Failed to fetch page data:", e);
          } finally {
            setIsLoading(false);
          }
        };
        fetchData();
    }, []);

    if (isLoading) {
        return <div className="h-screen w-full flex items-center justify-center text-2xl font-bold">Loading Page...</div>;
    }
    if (error) {
        return <div className="h-screen w-full flex items-center justify-center text-red-500">{error}</div>;
    }
    if (!pageData) return null;

    const { comp1_heading, comp1_subheading, comp1_desc_p1, comp1_desc_p2 } = pageData;
    const { comp2_tagline, comp2_heading, comp2_benefits } = pageData;
    const { comp3_heading, comp3_subheading, comp3_img1_url, comp3_img2_url, comp3_playbook } = pageData;

    return (
        // Use a light gray background like the reference images
        <main className="bg-gray-50">
            <div className="container mx-auto max-w-7xl py-20 md:py-28 px-4 sm:px-6 lg:px-8 space-y-24 md:space-y-32">
                
                {/* --- Component 1: A Team of Experts (image_9e2b2b.png) --- */}
                <section>
                    <div className="flex items-center gap-4 mb-8">
                        <svg className="w-8 h-8 text-[#d90a2c]" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M12 0L14.694 9.306H24L16.653 15.064L19.347 24L12 18.694L4.653 24L7.347 15.064L0 9.306H9.306L12 0Z" />
                        </svg>
                        <div className="flex gap-2">
                            <span className="border border-gray-400 text-gray-500 text-xs font-bold px-3 py-1 rounded-full">WHO</span>
                            <span className="border border-gray-400 text-gray-500 text-xs font-bold px-3 py-1 rounded-full">WE</span>
                            <span className="border border-gray-400 text-gray-500 text-xs font-bold px-3 py-1 rounded-full">ARE</span>
                        </div>
                    </div>
                    
                    <h1 
                        className="text-6xl md:text-7xl font-bold text-black uppercase"
                        style={{ fontFamily: "'Urbanist', sans-serif" }}
                    >
                        {comp1_heading}
                    </h1>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-16 mt-12">
                        <h2 
                            className="text-xl font-semibold text-black uppercase"
                            style={{ fontFamily: "'Urbanist', sans-serif" }}
                        >
                            {comp1_subheading}
                        </h2>
                        <div className="space-y-6">
                            <p className="text-base text-gray-600 leading-relaxed">
                                {comp1_desc_p1}
                            </p>
                            <p className="text-base text-gray-600 leading-relaxed">
                                {comp1_desc_p2}
                            </p>
                        </div>
                    </div>
                </section>

                {/* --- Component 2: Discover the Benefits (image_9e2fa3.png) --- */}
                <section>
                    {/* Header */}
                    <div className="text-center mb-12">
                        <span className="inline-block bg-[#d90a2c]/10 text-[#d90a2c] text-xs font-bold px-4 py-2 rounded-full uppercase">
                            {comp2_tagline}
                        </span>
                        <h2 
                            className="text-4xl md:text-5xl font-bold text-black mt-4"
                            style={{ fontFamily: "'Urbanist', sans-serif" }}
                            dangerouslySetInnerHTML={createMarkup(comp2_heading)}
                        />
                    </div>

                    {/* Benefits Grid */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                        {comp2_benefits.map((benefit, index) => (
                            <div key={index} className="bg-white p-8 rounded-xl shadow-lg border border-gray-100">
                                <div className="w-full h-32 mb-6">
                                    {BenefitIcons[index]}
                                </div>
                                <h3 
                                    className="text-xl font-bold text-black mb-3"
                                    style={{ fontFamily: "'Urbanist', sans-serif" }}
                                >
                                    {benefit.title}
                                </h3>
                                <p className="text-base text-gray-600 leading-relaxed">
                                    {benefit.description}
                                </p>
                            </div>
                        ))}
                    </div>
                </section>

                {/* --- Component 3: Company Playbook (image_9e2ba6.jpg) --- */}
                <section>
                    {/* Header */}
                    <div className="mb-12">
                        <h2 
                            className="text-5xl md:text-6xl font-bold text-black"
                            style={{ fontFamily: "'Urbanist', sans-serif" }}
                        >
                            {comp3_heading}
                        </h2>
                        <h3 
                            className="text-5xl md:text-6xl font-bold text-gray-400"
                            style={{ fontFamily: "'Urbanist', sans-serif" }}
                        >
                            {comp3_subheading}
                        </h3>
                    </div>

                    {/* Image Grid */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
                        <img 
                            src={comp3_img1_url} 
                            alt="Company culture" 
                            className="w-full h-80 object-cover rounded-xl"
                        />
                        <img 
                            src={comp3_img2_url}
                            alt="Company office" 
                            className="w-full h-80 object-cover rounded-xl"
                        />
                    </div>

                    {/* Playbook Grid */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-12">
                        {comp3_playbook.map((item) => (
                            <div key={item.number}>
                                <span className="text-gray-400 font-bold text-2xl">{item.number}</span>
                                <h4 
                                    className="text-2xl font-bold text-black my-3"
                                    style={{ fontFamily: "'Urbanist', sans-serif" }}
                                >
                                    {item.title}
                                </h4>
                                <p className="text-base text-gray-600 leading-relaxed">
                                    {item.description}
                                </p>
                            </div>
                        ))}
                    </div>
                </section>

            </div>
        </main>
    );
}