import React, { useState, useEffect } from 'react';

// Helper function to render HTML from string
const createMarkup = (htmlString) => {
    return { __html: htmlString };
};

// --- SVG Icons for Component 1 Features ---
const FeatureIcon1 = () => ( // "Our Evolution" (Trend up)
    <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
    </svg>
);

// --- UPDATED CLEAN ICON ---
const FeatureIcon2 = () => ( // "Our Impact" (Target/Reticle)
    <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
);
// --- END UPDATED ICON ---


// --- SVG Icons for Component 3 Values ---
const IconExcellence = () => ( // Icon for "Excellence"
    <svg className="w-full h-full text-[#d90a2c] opacity-10" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M32 4L40.237 20.9159L58.944 23.4729L45.472 36.5271L48.714 55.0841L32 46.25L15.286 55.0841L18.528 36.5271L5.056 23.4729L23.763 20.9159L32 4Z" stroke="currentColor" strokeWidth="4" strokeLinejoin="round"/>
    </svg>
);
const IconInnovation = () => ( // Icon for "Innovation" (lightbulb)
    <svg className="w-full h-full text-[#d90a2c] opacity-10" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M36 49.3333C36 53.0152 32.868 56 29 56C25.132 56 22 53.0152 22 49.3333M36 49.3333C36 45.6514 32.868 42.6667 29 42.6667C25.132 42.6667 22 45.6514 22 49.3333M36 49.3333H40C46.6274 49.3333 52 44.1838 52 37.8667C52 31.5495 46.6274 26.4 40 26.4H36M22 49.3333H18C11.3726 49.3333 6 44.1838 6 37.8667C6 31.5495 11.3726 26.4 18 26.4H22M36 26.4V12C36 8.68629 32.866 6 29 6C25.134 6 22 8.68629 22 12V26.4M36 26.4H22" stroke="currentColor" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
);
const IconPartnership = () => ( // Icon for "Partnership" (puzzle)
    <svg className="w-full h-full text-[#d90a2c] opacity-10" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M42 22H32V12H22V22H12V32H22V42H32V52H42V42H52V32H42V22Z" stroke="currentColor" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M32 32H22" stroke="currentColor" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
);

// Match icons to the data order
const ValueIcons = [<IconExcellence />, <IconInnovation />, <IconPartnership />];

export default function OurStoryPage() {
    const [pageData, setPageData] = useState(null);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        window.scrollTo(0, 0);
        const fetchData = async () => {
          setIsLoading(true);
          setError(null);
          try {
            const response = await fetch('http://localhost:8000/api/our-story-data');
            if (!response.ok) throw new Error(`Data fetching failed for Our Story page`);
            const data = await response.json();
            setPageData(data);
          } catch (e) {
            setError(e.message);
            console.error("Failed to fetch page data:", e);
          } finally {
            setIsLoading(false);
          }
        };
        fetchData();
    }, []);

    if (isLoading) {
        return <div className="h-screen w-full flex items-center justify-center text-2xl font-bold">Loading Page...</div>;
    }
    if (error) {
        return <div className="h-screen w-full flex items-center justify-center text-red-500">{error}</div>;
    }
    if (!pageData) return null;

    const { comp1_tagline, comp1_heading, comp1_description, comp1_imageUrl, comp1_features } = pageData;
    const { comp2_heading, comp2_description, comp2_imageUrl, comp2_serviceList } = pageData;
    const { comp3_heading, comp3_subheading, comp3_valueList } = pageData;

    return (
        <main className="bg-white">
            <div className="container mx-auto max-w-7xl py-20 md:py-28 px-4 sm:px-6 lg:px-8 space-y-24 md:space-y-32">
                
                {/* --- Component 1: Heart of Our Journey (image_9cd5ee.jpg) --- */}
                <section>
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 md:gap-16 items-center">
                        
                        {/* Left Content */}
                        <div className="space-y-6">
                            <span className="inline-block bg-[#d90a2c]/10 text-[#d90a2c] text-xs font-bold px-4 py-2 rounded-full uppercase">
                                {comp1_tagline}
                            </span>
                            <h1 
                                className="text-4xl md:text-5xl font-bold text-black"
                                style={{ fontFamily: "'Urbanist', sans-serif" }}
                                dangerouslySetInnerHTML={createMarkup(comp1_heading)}
                            />
                            <p className="text-base text-gray-600 leading-relaxed">
                                {comp1_description}
                            </p>
                            
                            {/* Features */}
                            <div className="space-y-5 pt-4">
                                {comp1_features.map((feature, index) => (
                                    <div key={index} className="flex items-start gap-4">
                                        <div className="flex-shrink-0 w-12 h-12 rounded-full bg-[#d90a2c]/10 text-[#d90a2c] flex items-center justify-center">
                                            {index === 0 ? <FeatureIcon1 /> : <FeatureIcon2 />}
                                        </div>
                                        <div>
                                            <h4 className="text-lg font-bold text-black">{feature.title}</h4>
                                            <p className="text-base text-gray-600 leading-relaxed">
                                                {feature.description}
                                            </p>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>

                        {/* Right Image */}
                        <div>
                            <img
                                src={comp1_imageUrl}
                                alt="Our journey"
                                className="w-full h-full object-cover rounded-2xl shadow-lg"
                            />
                        </div>
                    </div>
                </section>

                {/* --- Component 2: Our Expertise (image_9d2c9b.jpg) --- */}
                <section>
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 md:gap-16">
                        
                        {/* Left Column (Title, Text, Image) */}
                        <div className="space-y-6">
                            <h2 
                                className="text-5xl md:text-6xl font-bold text-black"
                                style={{ fontFamily: "'Urbanist', sans-serif" }}
                                dangerouslySetInnerHTML={createMarkup(comp2_heading)}
                            />
                            <p className="text-base text-gray-600 leading-relaxed">
                                {comp2_description}
                            </p>
                            <img
                                src={comp2_imageUrl}
                                alt="Our expertise"
                                className="w-full h-[400px] object-cover rounded-2xl shadow-lg"
                            />
                        </div>

                        {/* Right Column (List of Services) */}
                        <div className="space-y-10 lg:pt-16">
                            {comp2_serviceList.map((service, index) => (
                                <div key={index}>
                                    <h3 
                                        className="text-2xl font-bold text-black uppercase"
                                        style={{ fontFamily: "'Urbanist', sans-serif" }}
                                    >
                                        {service.title}
                                    </h3>
                                    <p className="text-base text-gray-600 leading-relaxed mt-2">
                                        {service.description}
                                    </p>
                                </div>
                            ))}
                        </div>
                    </div>
                </section>

                {/* --- Component 3: Core Values (image_9cb7a2.png) --- */}
                <section className="bg-gray-50/70 p-8 md:p-16 rounded-2xl">
                    {/* Header */}
                    <div className="max-w-3xl mb-12">
                        <h2 
                            className="text-4xl md:text-5xl font-bold text-black"
                            style={{ fontFamily: "'Urbanist', sans-serif" }}
                            dangerouslySetInnerHTML={createMarkup(comp3_heading)}
                        />
                        <p className="text-base text-gray-500 leading-relaxed mt-4">
                            {comp3_subheading}
                        </p>
                    </div>

                    {/* Values Grid */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        
                        {/* Top Row (Items 1 & 2) */}
                        {comp3_valueList.slice(0, 2).map((value, index) => (
                            <div key={value.number} className="relative bg-white p-8 rounded-xl shadow-lg overflow-hidden">
                                <div className="relative z-10">
                                    <span className="flex items-center justify-center w-10 h-10 rounded-full bg-gray-100 text-gray-500 font-bold">
                                        {value.number}
                                    </span>
                                    <h4 
                                        className="text-xl font-bold text-black mt-6"
                                        style={{ fontFamily: "'Urbanist', sans-serif" }}
                                    >
                                        {value.title}
                                    </h4>
                                    <p className="text-base text-gray-600 leading-relaxed mt-2">
                                        {value.description}
                                    </p>
                                </div>
                                {/* Background Icon */}
                                <div className="absolute -right-8 -bottom-8 w-40 h-40 z-0">
                                    {ValueIcons[index]}
                                </div>
                            </div>
                        ))}
                        
                        {/* Bottom Row (Item 3) */}
                        {comp3_valueList.slice(2).map((value, index) => (
                            <div key={value.number} className="relative bg-white p-8 rounded-xl shadow-lg md:col-span-2 overflow-hidden">
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
                                    {/* Text Content */}
                                    <div className="relative z-10">
                                        <span className="flex items-center justify-center w-10 h-10 rounded-full bg-gray-100 text-gray-500 font-bold">
                                            {value.number}
                                        </span>
                                        <h4 
                                            className="text-xl font-bold text-black mt-6"
                                            style={{ fontFamily: "'Urbanist', sans-serif" }}
                                        >
                                            {value.title}
                                        </h4>
                                        <p className="text-base text-gray-600 leading-relaxed mt-2">
                                            {value.description}
                                        </p>
                                    </div>
                                    {/* Background Icon (larger on this card) */}
                                    <div className="relative h-40 md:h-full min-h-[160px]">
                                        <div className="absolute inset-0 flex items-center justify-center md:absolute md:-right-10 md:top-1/2 md:-translate-y-1/2 md:w-60 md:h-60 z-0">
                                            {/* We use index 2 (the 3rd icon) for this card */}
                                            {ValueIcons[2]} 
                                        </div>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </section>

            </div>
        </main>
    );
}