import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';

// --- FIX: ADD LAYOUT COMPONENT IMPORTS ---
import Header from "./components/Header";
import Sidebar from "./components/Sidebar";
import Footer from './components/Footer';
import ScrollToTopButton from './components/ScrollToTopButton';
// --- END FIX ---

// Import Page Components
import HomePage from './pages/HomePage';
import ServicesPage from './pages/ServicesPage';
import SolutionsPage from './pages/SolutionsPage';
import IndustriesPage from './pages/IndustriesPage';
import CareersPage from './pages/CareersPage';
import ContactPage from './pages/ContactPage';
import ClientPortalPage from './pages/ClientPortalPage';
import AboutPage from './pages/AboutPage';
import MissionVisionPage from './pages/MissionVisionPage';
import OurStoryPage from './pages/OurStoryPage';
import OurTeamPage from './pages/OurTeamPage';

// Service Pages
import SoftwareDevelopmentPage from './pages/services/SoftwareDevelopmentPage';
import WebDevelopmentPage from './pages/services/WebDevelopmentPage';
import MobileDevelopmentPage from './pages/services/MobileDevelopmentPage';
import EnterpriseSoftwarePage from './pages/services/EnterpriseSoftwarePage';
import ITConsultingPage from './pages/services/ITConsultingPage';
import DigitalTransformationPage from './pages/services/DigitalTransformationPage';
import LegacyModernizationPage from './pages/services/LegacyModernizationPage';
import SystemIntegrationPage from './pages/services/SystemIntegrationPage';
import BusinessIntelligencePage from './pages/services/BusinessIntelligencePage';
import ITStrategyPage from './pages/services/ITStrategyPage';

// Solution Pages
import DigitalTransformationSolutionPage from './pages/solutions/DigitalTransformationPage';

// Industry Pages
import EducationPage from './pages/industries/EducationPage';


export default function App() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [footerData, setFooterData] = useState(null);

  useEffect(() => {
     const fetchLayoutData = async () => {
      try {
        const response = await fetch('http://localhost:8000/api/home-data');
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        setFooterData(data.footerData);
      } catch (e) {
        console.error("Failed to fetch layout data:", e);
      }
    };
    fetchLayoutData();
  }, []);


  return (
    <BrowserRouter>
      <style>{`
        /* ... your keyframes and styles ... */
        @keyframes progress { from { width: 0%; } to { width: 100%; } }
        @keyframes pulse-slow {
          0%, 100% { transform: scale(0.95); opacity: 0.5; }
          70% { transform: scale(1.4); opacity: 0; }
        }
        .animate-pulse-slow { animation: pulse-slow 2s cubic-bezier(0.4, 0, 0.6, 1) infinite; }
        
        .form-input:focus ~ .form-label,
        .form-input:not(:placeholder-shown) ~ .form-label {
            transform: translateY(-1.5rem) scale(0.8);
        }
      `}</style>
      
      <div className="bg-white text-gray-800" style={{ fontFamily: "'Outfit', sans-serif" }}>
        
        <Header onSidebarOpen={() => setIsSidebarOpen(true)} />
        <Sidebar isOpen={isSidebarOpen} onClose={() => setIsSidebarOpen(false)} />

        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/about/mission-vision" element={<MissionVisionPage />} />
          <Route path="/about/our-story" element={<OurStoryPage />} />
          <Route path="/about/our-team" element={<OurTeamPage />} />
          
          {/* Service Routes */}
          <Route path="/services" element={<ServicesPage />} />
          <Route path="/services/software-development" element={<SoftwareDevelopmentPage />} />
          <Route path="/services/web-development" element={<WebDevelopmentPage />} />
          <Route path="/services/mobile-development" element={<MobileDevelopmentPage />} />
          <Route path="/services/enterprise" element={<EnterpriseSoftwarePage />} />
          <Route path="/services/it-consulting" element={<ITConsultingPage />} />
          <Route path="/services/digital-transformation" element={<DigitalTransformationPage />} />
          <Route path="/services/legacy-modernization" element={<LegacyModernizationPage />} />
          <Route path="/services/system-integration" element={<SystemIntegrationPage />} />
          <Route path="/services/business-intelligence" element={<BusinessIntelligencePage />} />
          <Route path="/services/it-strategy" element={<ITStrategyPage />} />
          
          {/* Solution Routes */}
          <Route path="/solutions" element={<SolutionsPage />} />
          <Route path="/solutions/digital-transformation" element={<DigitalTransformationSolutionPage />} />
          
          {/* Industry Routes */}
          <Route path="/industries" element={<IndustriesPage />} />
          <Route path="/industries/education" element={<EducationPage />} />

          {/* Other Routes */}
          <Route path="/careers" element={<CareersPage />} /> 
          <Route path="/contact" element={<ContactPage />} /> 
          <Route path="/client-portal" element={<ClientPortalPage />} />
        </Routes>
        
        <Footer footerData={footerData} /> 
        <ScrollToTopButton />
      </div>
    </BrowserRouter>
  );
}

